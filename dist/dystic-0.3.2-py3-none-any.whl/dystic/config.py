import os
import sys
ROOT_DIR_PATH = os.getcwd()
# try:
#     ROOT_DIR_PATH = os.path.abspath(os.path.dirname(sys.argv[0]))
# except IndexError:
#     raise SystemExit('Not a valid dystic command. Run `dystic -h` for HELP.')

DYSTIC_DIR = os.getcwd()
