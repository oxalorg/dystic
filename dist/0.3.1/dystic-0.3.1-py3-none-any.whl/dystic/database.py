"""
Manages a dictionary with metadata about the built site.
Useful for incremental builds.
"""
