import os
import sys
ROOT_DIR_PATH = os.path.abspath(os.path.dirname(sys.argv[1]))
DYSTIC_DIR = os.getcwd()
