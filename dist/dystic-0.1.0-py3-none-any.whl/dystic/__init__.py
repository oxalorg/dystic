from .main import main
_VERSION = '0.1.0'
